import 'dart:io';

import 'package:google_mlkit_document_scanner/google_mlkit_document_scanner.dart';
import 'package:image_picker/image_picker.dart';

/// Thin wrapper around the on-device ML Kit document scanner.
///
/// The scanner UI (edge detection, auto-capture, crop, filters) is provided by
/// Google Play services, so no model ships inside this app and no camera
/// permission is required from us. We only receive the resulting image files.
class ScanService {
  DocumentScanner? _scanner;

  Future<List<String>> scan({
    int pageLimit = 20,
    bool galleryImport = true,
  }) async {
    final options = DocumentScannerOptions(
      documentFormats: const {DocumentFormat.jpeg},
      mode: ScannerMode.filter,
      pageLimit: pageLimit,
      isGalleryImport: galleryImport,
    );

    _scanner?.close();
    _scanner = DocumentScanner(options: options);
    try {
      final result = await _scanner!.scanDocument();
      final images = result.images ?? const <String>[];
      return images
          .where((path) => path.isNotEmpty && File(path).existsSync())
          .toList();
    } finally {
      _scanner?.close();
      _scanner = null;
    }
  }

  /// Fallback for devices without Play services: pick photos from the gallery.
  Future<List<String>> pickFromGallery() async {
    final picker = ImagePicker();
    final files = await picker.pickMultiImage(imageQuality: 95);
    return files.map((f) => f.path).toList();
  }

  void dispose() {
    _scanner?.close();
    _scanner = null;
  }
}
