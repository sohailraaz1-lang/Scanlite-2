import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/scan_document.dart';

/// Stores documents as a JSON index plus one image file per page.
///
/// Layout (inside the app's private documents directory):
///   scanlite/index.json
///   scanlite/pages/<pageId>.jpg
///
/// Nothing leaves the device unless the user explicitly shares or exports.
class DocumentStore {
  DocumentStore._();

  static final DocumentStore instance = DocumentStore._();

  Directory? _root;
  final List<ScanDocument> _documents = [];
  bool _loaded = false;

  List<ScanDocument> get documents => List.unmodifiable(_documents);

  Future<Directory> _ensureRoot() async {
    if (_root != null) return _root!;
    final base = await getApplicationDocumentsDirectory();
    final root = Directory(p.join(base.path, 'scanlite'));
    final pages = Directory(p.join(root.path, 'pages'));
    if (!await pages.exists()) {
      await pages.create(recursive: true);
    }
    _root = root;
    return root;
  }

  Future<File> _indexFile() async {
    final root = await _ensureRoot();
    return File(p.join(root.path, 'index.json'));
  }

  Future<void> load() async {
    if (_loaded) return;
    await _ensureRoot();
    final file = await _indexFile();
    _documents.clear();
    if (await file.exists()) {
      try {
        final raw = jsonDecode(await file.readAsString());
        for (final entry in (raw as List<dynamic>)) {
          _documents.add(
            ScanDocument.fromJson(entry as Map<String, dynamic>),
          );
        }
      } on FormatException {
        // Corrupt index: start clean rather than crash on launch.
        _documents.clear();
      }
    }
    _documents.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    _loaded = true;
  }

  Future<void> _persist() async {
    final file = await _indexFile();
    final payload = _documents.map((d) => d.toJson()).toList();
    await file.writeAsString(jsonEncode(payload), flush: true);
  }

  Future<String> pagePath(String fileName) async {
    final root = await _ensureRoot();
    return p.join(root.path, 'pages', fileName);
  }

  /// Copies a freshly scanned image into app storage and returns its file name.
  Future<String> importPageFile(String sourcePath, String pageId) async {
    final root = await _ensureRoot();
    final ext = p.extension(sourcePath).isEmpty ? '.jpg' : p.extension(sourcePath);
    final fileName = '$pageId$ext';
    final target = File(p.join(root.path, 'pages', fileName));
    await File(sourcePath).copy(target.path);
    return fileName;
  }

  Future<void> addDocument(ScanDocument document) async {
    _documents.insert(0, document);
    await _persist();
  }

  Future<void> updateDocument(ScanDocument document) async {
    document.modifiedAt = DateTime.now();
    _documents.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    await _persist();
  }

  Future<void> deleteDocument(ScanDocument document) async {
    _documents.removeWhere((d) => d.id == document.id);
    for (final page in document.pages) {
      final f = File(await pagePath(page.fileName));
      if (await f.exists()) {
        await f.delete();
      }
    }
    await _persist();
  }

  Future<void> deletePage(ScanDocument document, ScanPage page) async {
    document.pages.removeWhere((p) => p.id == page.id);
    final f = File(await pagePath(page.fileName));
    if (await f.exists()) {
      await f.delete();
    }
    await updateDocument(document);
  }
}
