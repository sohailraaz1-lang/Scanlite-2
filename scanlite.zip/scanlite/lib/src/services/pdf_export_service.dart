import 'dart:io';
import 'dart:typed_data';

import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/scan_document.dart';
import 'document_store.dart';

/// Builds a PDF from a document's pages and writes it to a temp file.
class PdfExportService {
  /// Renders each page image into an A4 PDF, honouring per-page rotation.
  Future<File> buildPdf(ScanDocument document) async {
    final doc = pw.Document();
    final store = DocumentStore.instance;

    for (final page in document.pages) {
      final path = await store.pagePath(page.fileName);
      final file = File(path);
      if (!await file.exists()) continue;

      Uint8List bytes = await file.readAsBytes();
      if (page.rotationQuarterTurns % 4 != 0) {
        final decoded = img.decodeImage(bytes);
        if (decoded != null) {
          final rotated = img.copyRotate(
            decoded,
            angle: 90.0 * (page.rotationQuarterTurns % 4),
          );
          bytes = Uint8List.fromList(img.encodeJpg(rotated, quality: 92));
        }
      }

      final image = pw.MemoryImage(bytes);
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(18),
          build: (context) => pw.Center(
            child: pw.Image(image, fit: pw.BoxFit.contain),
          ),
        ),
      );
    }

    final dir = await getTemporaryDirectory();
    final safeName = document.title
        .replaceAll(RegExp(r'[^A-Za-z0-9 _-]'), '')
        .trim()
        .replaceAll(' ', '_');
    final out = File(
      p.join(
        dir.path,
        '${safeName.isEmpty ? 'scanlite_document' : safeName}.pdf',
      ),
    );
    await out.writeAsBytes(await doc.save(), flush: true);
    return out;
  }

  /// Writes a single page image (with rotation applied) to a temp file.
  Future<File> exportPageImage(ScanPage page) async {
    final store = DocumentStore.instance;
    final source = File(await store.pagePath(page.fileName));
    final dir = await getTemporaryDirectory();
    final out = File(p.join(dir.path, 'scanlite_${page.id}.jpg'));

    if (page.rotationQuarterTurns % 4 == 0) {
      await source.copy(out.path);
      return out;
    }

    final decoded = img.decodeImage(await source.readAsBytes());
    if (decoded == null) {
      await source.copy(out.path);
      return out;
    }
    final rotated = img.copyRotate(
      decoded,
      angle: 90.0 * (page.rotationQuarterTurns % 4),
    );
    await out.writeAsBytes(img.encodeJpg(rotated, quality: 92), flush: true);
    return out;
  }
}
