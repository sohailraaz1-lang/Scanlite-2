import 'package:flutter/material.dart';

import '../models/scan_document.dart';
import '../services/document_store.dart';
import '../services/scan_service.dart';
import '../theme/app_theme.dart';

/// Captures one or more pages via the scanner (or gallery fallback) and
/// imports them into app storage without creating a document entry yet.
Future<List<ScanPage>> capturePages(
  BuildContext context, {
  required String prefixId,
}) async {
  final service = ScanService();
  List<String> paths;
  try {
    paths = await service.scan();
  } catch (_) {
    if (!context.mounted) return const [];
    final fallback = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Scanner unavailable'),
        content: const Text(
          'The on-device scanner could not start (it needs Google Play '
          'services). You can still import pages from your gallery.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Import photos'),
          ),
        ],
      ),
    );
    if (fallback != true) return const [];
    try {
      paths = await service.pickFromGallery();
    } catch (_) {
      return const [];
    }
  } finally {
    service.dispose();
  }

  if (paths.isEmpty) return const [];
  final store = DocumentStore.instance;
  final pages = <ScanPage>[];
  for (var i = 0; i < paths.length; i++) {
    final pageId = '${prefixId}_p${DateTime.now().microsecondsSinceEpoch}_$i';
    final fileName = await store.importPageFile(paths[i], pageId);
    pages.add(ScanPage(id: pageId, fileName: fileName));
  }
  return pages;
}

/// Runs the full new-document capture flow and returns the saved document,
/// or null if cancelled.
Future<ScanDocument?> runScanFlow(BuildContext context) async {
  final now = DateTime.now();
  final docId = 'doc_${now.microsecondsSinceEpoch}';
  final pages = await capturePages(context, prefixId: docId);
  if (pages.isEmpty || !context.mounted) return null;

  final title = await _askTitle(context);
  if (title == null) {
    // User cancelled after scanning: clean up the imported files.
    final temp = ScanDocument(
      id: docId,
      title: '',
      createdAt: now,
      pages: pages,
    );
    await DocumentStore.instance.deleteDocument(temp);
    return null;
  }

  final doc = ScanDocument(
    id: docId,
    title: title,
    createdAt: now,
    pages: pages,
  );
  await DocumentStore.instance.addDocument(doc);
  return doc;
}

Future<String?> _askTitle(BuildContext context) {
  final controller = TextEditingController(
    text: 'Scan ${DateFormatHelper.stamp(DateTime.now())}',
  );
  return showDialog<String>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Name this document'),
      content: TextField(
        controller: controller,
        autofocus: true,
        textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(
          labelText: 'Title',
          border: OutlineInputBorder(),
        ),
        onSubmitted: (v) => Navigator.pop(context, v.trim()),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () {
            final v = controller.text.trim();
            Navigator.pop(context, v.isEmpty ? 'Untitled scan' : v);
          },
          child: const Text('Save'),
        ),
      ],
    ),
  );
}

class DateFormatHelper {
  static String stamp(DateTime d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${two(d.month)}-${two(d.day)} '
        '${two(d.hour)}:${two(d.minute)}';
  }
}

/// Small helper widget used by the document screen for section headers.
class SectionLabel extends StatelessWidget {
  const SectionLabel(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        text.toUpperCase(),
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: AppColors.inkSoft,
              letterSpacing: 1.1,
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}
