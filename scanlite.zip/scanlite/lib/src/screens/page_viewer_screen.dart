import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models/scan_document.dart';
import '../services/document_store.dart';
import '../services/pdf_export_service.dart';
import '../theme/app_theme.dart';

/// Full-screen page viewer with rotate, delete and share actions.
class PageViewerScreen extends StatefulWidget {
  const PageViewerScreen({
    super.key,
    required this.document,
    required this.initialIndex,
  });

  final ScanDocument document;
  final int initialIndex;

  @override
  State<PageViewerScreen> createState() => _PageViewerScreenState();
}

class _PageViewerScreenState extends State<PageViewerScreen> {
  final _store = DocumentStore.instance;
  final _pdf = PdfExportService();
  late final PageController _controller =
      PageController(initialPage: widget.initialIndex);
  late int _index = widget.initialIndex;

  ScanDocument get doc => widget.document;

  Future<void> _rotate() async {
    final page = doc.pages[_index];
    page.rotationQuarterTurns = (page.rotationQuarterTurns + 1) % 4;
    await _store.updateDocument(doc);
    if (mounted) setState(() {});
  }

  Future<void> _delete() async {
    if (doc.pages.length == 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('A document needs at least one page.')),
      );
      return;
    }
    final page = doc.pages[_index];
    await _store.deletePage(doc, page);
    if (!mounted) return;
    setState(() {
      _index = _index.clamp(0, doc.pages.length - 1);
    });
    _controller.jumpToPage(_index);
  }

  Future<void> _sharePage() async {
    final page = doc.pages[_index];
    final file = await _pdf.exportPageImage(page);
    await SharePlus.instance.share(
      ShareParams(files: [XFile(file.path)], text: doc.title),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final page = doc.pages[_index];
    return Scaffold(
      backgroundColor: AppColors.ink,
      appBar: AppBar(
        backgroundColor: AppColors.ink,
        foregroundColor: Colors.white,
        titleTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 17,
          fontWeight: FontWeight.w600,
        ),
        title: Text('Page ${_index + 1} of ${doc.pages.length}'),
        actions: [
          IconButton(
            tooltip: 'Rotate',
            onPressed: _rotate,
            icon: const Icon(Icons.rotate_right),
          ),
          IconButton(
            tooltip: 'Share page',
            onPressed: _sharePage,
            icon: const Icon(Icons.ios_share),
          ),
          IconButton(
            tooltip: 'Delete page',
            onPressed: _delete,
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
      body: PageView.builder(
        controller: _controller,
        itemCount: doc.pages.length,
        onPageChanged: (i) => setState(() => _index = i),
        itemBuilder: (context, index) {
          final p = doc.pages[index];
          return FutureBuilder<String>(
            future: _store.pagePath(p.fileName),
            builder: (context, snapshot) {
              final path = snapshot.data ?? '';
              if (path.isEmpty) {
                return const Center(child: CircularProgressIndicator());
              }
              return InteractiveViewer(
                maxScale: 4,
                child: Center(
                  child: RotatedBox(
                    quarterTurns: p.rotationQuarterTurns,
                    child: Image.file(
                      File(path),
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.broken_image_outlined,
                        color: Colors.white54,
                        size: 48,
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  page.ocrText == null || page.ocrText!.isEmpty
                      ? 'No text extracted for this page'
                      : 'Text extracted · ${page.ocrText!.length} characters',
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
